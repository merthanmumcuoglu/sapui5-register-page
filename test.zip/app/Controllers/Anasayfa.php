<?php namespace App\Controllers;

class Anasayfa extends BaseController
{
	public function index()
	{
		return view('index');
	}

	//--------------------------------------------------------------------

}
